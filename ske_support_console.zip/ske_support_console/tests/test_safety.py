import pytest
from support_console.safety import validate_name, validate_resource_type, SAFE_BUNDLE_ITEMS

def test_valid_names(): assert validate_name("payment-api-1") == "payment-api-1"
def test_reject_shellish_name():
    with pytest.raises(ValueError): validate_name("pod;whoami")
def test_reject_unknown_resource():
    with pytest.raises(ValueError): validate_resource_type("nodes;rm")
def test_no_raw_secret_export_choices():
    assert "raw_secrets" not in SAFE_BUNDLE_ITEMS
    assert "tokens" not in SAFE_BUNDLE_ITEMS
    assert "raw_kubeconfig" not in SAFE_BUNDLE_ITEMS
