from support_console.health_service import pod_health, summarize

def pod(reason=None,restarts=0,ready=True):
    state={"waiting":{"reason":reason}} if reason else {"running":{}}
    return {"metadata":{"name":"p1","namespace":"ns"},"spec":{"nodeName":"n1"},"status":{"phase":"Running","conditions":[{"type":"Ready","status":"True" if ready else "False"}],"containerStatuses":[{"name":"c","ready":ready,"restartCount":restarts,"image":"repo/app:1","imageID":"repo/app@sha256:abc","state":state,"lastState":{}}]}}

def test_crashloop_is_critical(): assert pod_health(pod("CrashLoopBackOff",4))["health"]=="CRITICAL"
def test_restart_is_warning(): assert pod_health(pod(None,1))["health"]=="WARNING"
def test_summary(): assert summarize([pod()])["summary"]["overall"]=="HEALTHY"
