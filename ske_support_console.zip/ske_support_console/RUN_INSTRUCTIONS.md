# Run Instructions — Windows

## 1. Copy/extract the project

Extract the ZIP to a local folder, for example:

```text
C:\Tools\ske_support_console
```

Do not run the application from a shared writable folder unless your organization explicitly allows it.

## 2. Verify prerequisites

Open PowerShell and verify:

```powershell
py --version
kubectl version --client
kubectl config get-contexts
```

Recommended Python: 3.11+.

## 3. Configure cluster/identity contexts

Edit:

```text
config\clusters.yaml
```

Replace the sample contexts with the approved kubeconfig context names for:

- HK Support Read Only
- HK HP Read/Write
- SG Support Read Only
- SG HP Read/Write

Example:

```yaml
clusters:
  HK:
    read_only_context: hk-support-readonly
    read_write_context: hk-hp-readwrite
  SG:
    read_only_context: sg-support-readonly
    read_write_context: sg-hp-readwrite
```

## 4. Configure default email recipients

Edit:

```text
config\mail.yaml
```

The UI also allows To/CC recipients to be entered for each draft.

## 5. Start with PowerShell

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

Or with Command Prompt:

```cmd
run.bat
```

The startup script creates `.venv`, installs dependencies, and launches the local application.

## 6. Open the UI

Open a browser to:

```text
http://127.0.0.1:5080
```

The service listens only on the local machine by default.

## 7. First connection test

1. Select `HK` or `SG`.
2. Keep `Support Read Only` selected initially.
3. Click **Load Namespaces**.
4. Select a namespace.
5. Click **Connect**.
6. Confirm the displayed context and RBAC permissions.
7. Run **Health Check**.

## 8. Deployment watch

1. Open **Deployment Watch**.
2. Enter the Deployment name.
3. Click **Capture Pre-Deployment Baseline**.
4. Click **Start Watch**.
5. Watch desired/updated/ready/available/unavailable counts and individual pod health.
6. If a new pod fails, click its health entry from the dashboard or open **Logs & Crash Investigation** and enter the pod/container.
7. Review current logs, `--previous` logs, describe output, and events.
8. After rollout, use **Compare Pre/Post Baseline**.

## 9. Read/Write operations

Before a production change:

1. Switch to **HP Read/Write**.
2. Confirm the UI border is RED and the warning banner is visible.
3. Click **Connect** again and verify RBAC.
4. Use **Backup & Compare** to take/inspect a backup if desired.
5. For YAML changes, use **Load Current YAML**, edit only approved fields, then:
   - **Compare Proposed vs Current**
   - **Dry Run**
   - **Backup + Apply**
6. For restart, use **Restart Deployment** from Deployment Watch.
7. For rollback, optionally enter a revision and use **Rollback Deployment**.

The backend also creates a backup before supported apply/restart/rollback operations.

## 10. Create a diagnostic ZIP

Open **ZIP & Email** and select only the required items.

Available items include:

- Health summary
- Pod describe
- Current logs
- Previous-container logs
- Kubernetes events
- Deployment YAML
- Configured/runtime image and image IDs
- Recent audit summary
- Redacted kubeconfig metadata
- Secret names/types/key names only
- ServiceAccount references

Plaintext credentials, bearer tokens, private keys, and Kubernetes Secret values are not exportable by this application.

## 11. Open an Outlook draft

1. Enter optional To/CC recipients or use defaults from `config\mail.yaml`.
2. Click **Create ZIP**.
3. Click **Open Outlook Draft with ZIP**.
4. Review recipients, subject, body, and attachment.
5. Send manually from Outlook.

The implementation uses Windows COM through `pywin32`. It requires a COM-compatible Outlook desktop installation/profile. If your organization's Outlook build does not permit COM automation, use **Create ZIP** and attach the ZIP manually through the approved mail client.

## 12. Run tests

```powershell
.\.venv\Scripts\Activate.ps1
pytest -q
```

## 13. Local data locations

```text
backups\       Timestamped Kubernetes YAML backups
reports\       Diagnostic ZIP files
database\      SQLite audit/history database
logs\          Reserved for local application logs
```

Apply your organization's local filesystem ACL and retention requirements to these directories.
