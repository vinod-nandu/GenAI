# Kubernetes / SKE Production Support Console

A local Windows application for production support engineers who operate Kubernetes/SKE workloads through `kubectl` and need safe health checks, deployment monitoring, backups, log collection, pre/post deployment baselines, image/image-ID visibility, diagnostic ZIP generation, and Microsoft Outlook reporting.

The application uses **no LLM, no AI service, no external AI API, and no API key**.

## Key capabilities

- HK / SG cluster selection from a dropdown.
- Two identity profiles per cluster:
  - **Support Read Only** — green application border.
  - **HP Read/Write** — red application border and persistent production-change warning.
- Explicit Kubernetes context on every kubectl command; the app does not silently switch the workstation's global context.
- Kubernetes RBAC verification using `kubectl auth can-i`.
- Namespace discovery and pod health checks.
- Container image and runtime image-ID visibility.
- Restart-count monitoring and deterministic HEALTHY / WARNING / CRITICAL classification.
- Current and **previous-container** log capture (`kubectl logs --previous`).
- Pod `describe` and Kubernetes events for crash investigation.
- **Deployment Watch Mode** with 5-second UI polling.
- Pre-deployment baseline capture and post-deployment comparison.
- Automatic YAML backup before supported configuration changes or rollout restart.
- Server-side dry-run before supported YAML apply operations.
- Diagnostic ZIP builder with selectable contents.
- Outlook desktop draft creation with optional ZIP attachment.
- SQLite audit log, health history, and baseline storage.
- Local-only Flask server bound to `127.0.0.1`.

## Important security boundary for diagnostic bundles

The ZIP selection UI intentionally does **not** export plaintext kubeconfig credentials, bearer tokens, private keys, client certificates, or Kubernetes Secret values. Emailing those values creates a direct credential-exfiltration path.

Instead the application provides selectable safe troubleshooting artifacts:

- `kubeconfig_redacted` — cluster/context/user configuration with authentication material replaced by `<REDACTED>`.
- `secret_metadata` — Secret name, type, and key names only; no Secret data values.
- `serviceaccount_metadata` — ServiceAccount and referenced Secret/image-pull-secret names.

If your organization has an approved process for transferring raw credentials or Secret values, use its secure vault / secret-management / incident-transfer mechanism rather than email.

## Architecture

See:

- `diagrams/architecture.png`
- `diagrams/architecture.svg`
- `diagrams/architecture.dot`

Detailed design notes are also in `ARCHITECTURE.md`.

The application flow is in:

- `diagrams/flow.png`
- `diagrams/flow.svg`
- `diagrams/flow.dot`

## Project structure

```text
ske_support_console/
├── app.py
├── requirements.txt
├── run.bat
├── run.ps1
├── README.md
├── config/
│   ├── app.yaml
│   ├── clusters.yaml
│   ├── health_rules.yaml
│   └── mail.yaml
├── support_console/
│   ├── __init__.py
│   ├── audit_service.py
│   ├── backup_service.py
│   ├── baseline_service.py
│   ├── bundle_service.py
│   ├── config.py
│   ├── health_service.py
│   ├── kubectl_service.py
│   ├── outlook_service.py
│   ├── report_service.py
│   ├── routes.py
│   └── safety.py
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── styles.css
├── diagrams/
├── backups/
├── reports/
├── database/
├── logs/
└── tests/
```

## Prerequisites

On the Windows production-support workstation:

1. Python 3.11 or later.
2. `kubectl` installed and available on `PATH`.
3. Existing kubeconfig contexts for HK and SG.
4. Existing enterprise authentication/login process for both identities.
5. Microsoft Outlook desktop client if Outlook draft creation is required.
6. PowerShell or Command Prompt.

No Microsoft Graph registration, Azure application secret, API key, or AI service is required.

## Configure the four Kubernetes contexts

Edit `config/clusters.yaml`.

```yaml
clusters:
  HK:
    read_only_context: hk-support-readonly
    read_write_context: hk-hp-readwrite
  SG:
    read_only_context: sg-support-readonly
    read_write_context: sg-hp-readwrite
```

Replace the sample values with existing context names returned by:

```powershell
kubectl config get-contexts
```

The application executes commands in this form:

```powershell
kubectl --context <selected-context> ...
```

This avoids depending on `kubectl config use-context` and reduces accidental cluster switching outside the application.

## Configure Outlook defaults

Edit `config/mail.yaml`:

```yaml
clusters:
  HK:
    to:
      - hk-support-team@example.com
    cc:
      - operations@example.com
  SG:
    to:
      - sg-support-team@example.com
    cc:
      - operations@example.com
```

Replace these sample addresses before production use.

The app opens a **draft** in the installed Outlook desktop client. It does not silently send mail. Review recipients, subject, message, and ZIP attachment before sending.

For a concise Windows setup checklist, see `RUN_INSTRUCTIONS.md`.

## First run — PowerShell

Open PowerShell in the project directory:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

The script creates `.venv`, installs dependencies, and starts the application.

Then open:

```text
http://127.0.0.1:5080
```

## First run — Command Prompt

```cmd
run.bat
```

Then open:

```text
http://127.0.0.1:5080
```

## Manual installation

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

## Recommended operator workflow

### Health / investigation workflow

1. Select **HK** or **SG**.
2. Select **Support Read Only**.
3. Load namespaces and select the target namespace.
4. Click **Connect** to verify the context and RBAC capabilities.
5. Run **Health Check**.
6. For a failed/restarted pod, click **Investigate**.
7. Review:
   - pod describe
   - current logs
   - previous-container logs
   - events
8. Open **ZIP & Email**.
9. Select only required artifacts.
10. Create the ZIP.
11. Open an Outlook draft with the ZIP attached.
12. Review and send using the normal Outlook process.

### Deployment workflow

1. Select the cluster and namespace.
2. Start in **Support Read Only** whenever possible.
3. In **Deployment Watch**, enter the Deployment name.
4. Capture the **pre-deployment baseline**.
5. If a change is authorized, switch to **HP Read/Write**. The UI border becomes red.
6. Reconnect and verify RBAC.
7. For YAML changes, paste the approved YAML and run **Dry Run**.
8. Apply only after change review and confirmation. The application creates a backup first.
9. Start **Deployment Watch**.
10. Watch desired / updated / ready / available / unavailable replicas and new pod health.
11. If a new pod crashes, investigate current and previous logs.
12. After rollout, compare against the baseline.
13. Generate a diagnostic ZIP or health email if required.

## Health classification

The current implementation uses deterministic rules rather than AI.

Typical classifications:

- `HEALTHY`: ready, no recognized critical state, no restart warning.
- `WARNING`: not ready or has restart history.
- `CRITICAL`: failed/unknown pod or recognized critical container reason such as `CrashLoopBackOff`, `ImagePullBackOff`, `ErrImagePull`, `OOMKilled`, or `CreateContainerConfigError`.

A restart count by itself does **not** cause an automatic restart. The operator remains responsible for determining whether a rollout restart or another corrective action is appropriate.

## Deployment baseline

A baseline stores a health snapshot plus the selected Deployment object in SQLite. Post-deployment comparison reports:

- before / after summaries
- newly observed pods
- removed pods
- restart-count changes for pods present in both snapshots

Because Kubernetes Deployment pods frequently receive new ReplicaSet-derived names, also review Deployment Watch and new-pod status rather than relying only on identical pod names.

## Diagnostic ZIP options

The UI can select:

- health summary
- pod describe
- current logs
- previous logs
- namespace events
- Deployment YAML
- redacted kubeconfig metadata
- Secret names/types/key names only
- ServiceAccount references

Files are written to `reports/` and can be downloaded from the UI or attached to an Outlook draft.

## Backups

Supported configuration changes and rollout restart operations create timestamped YAML backups under:

```text
backups/<cluster>/<namespace>/<resource_type>_<resource_name>/
```

Existing backups are not overwritten.

## Audit data

SQLite database:

```text
database/support.db
```

The audit service records items such as:

- connection checks
- health checks
- pod investigations
- baseline captures
- backup creation
- configuration apply
- rollout restart
- diagnostic bundle creation
- Outlook draft creation

Authentication credentials are not written to the audit database.

## Safety design

- Read-only mode is the default UI mode.
- Green application border = Support Read Only.
- Red application border = HP Read/Write.
- Color is supplemented with text; color is never the only indicator.
- Every kubectl invocation uses an argument array, not a shell command string.
- `shell=True` is not used.
- Namespace/resource/pod/container names are validated.
- Cluster context is passed explicitly to every kubectl invocation.
- Kubernetes RBAC is checked separately from the UI dropdown.
- Supported configuration apply requires HP Read/Write mode.
- Supported changes perform a server-side dry run.
- Current configuration is backed up before apply/restart.
- Outlook uses the already-authenticated local desktop profile and opens a reviewable draft.
- Raw credential/Secret material is not placed into report ZIPs.

## Production hardening recommended before organizational rollout

This project is a functional reference implementation and should be validated against your organization's Kubernetes distribution, authentication mechanism, security policy, proxy configuration, and change-management process before broad production use.

Recommended hardening items:

- Map each HK/SG read-only/read-write option to dedicated approved kubeconfig contexts.
- Add corporate code signing for packaged executables/scripts if required.
- Restrict filesystem ACLs on `backups/`, `reports/`, and `database/`.
- Define log-retention and report-retention policies.
- Review whether Deployment YAML may contain sensitive environment values in your environment; redact additional fields if required.
- Add approved incident/change ticket reference fields if required by your process.
- Add organization-specific namespace allowlists/denylists.
- Add unit/integration tests against a non-production test cluster before production rollout.
- Consider packaging the Flask app as a signed Windows executable only after internal security review.

## Tests

Run:

```powershell
pytest -q
```

Current tests cover name validation, prohibited raw-secret bundle choices, and basic pod-health classification.

## Troubleshooting

### kubectl not found

Verify:

```powershell
kubectl version --client
```

and ensure `kubectl.exe` is on `PATH`.

### Context not found

Verify:

```powershell
kubectl config get-contexts
```

Then update `config/clusters.yaml`.

### Authentication expired

Use your approved enterprise login/authentication process for the applicable context, then reconnect from the application.

### Outlook draft does not open

Confirm:

- Microsoft Outlook desktop is installed.
- The desktop profile is configured and signed in.
- `pywin32` installed successfully inside `.venv`.

Then restart the application.

## No AI / API keys

This project deliberately contains no LLM integration. Kubernetes health decisions, status classifications, baselines, comparisons, logs, and reports are deterministic Python/kubectl operations.
