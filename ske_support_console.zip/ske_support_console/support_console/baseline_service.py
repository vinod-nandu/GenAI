import json
import sqlite3
from datetime import datetime, timezone

class BaselineService:
    def __init__(self, audit): self.audit = audit
    def capture(self, cluster, mode, namespace, workload, payload):
        ts=datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.audit.db_path) as con:
            cur=con.execute("INSERT INTO baselines(ts,cluster,mode,namespace,workload,payload) VALUES(?,?,?,?,?,?)",
                (ts,cluster,mode,namespace,workload,json.dumps(payload)))
            return cur.lastrowid
    def get(self, baseline_id):
        with sqlite3.connect(self.audit.db_path) as con:
            con.row_factory=sqlite3.Row
            row=con.execute("SELECT * FROM baselines WHERE id=?",(int(baseline_id),)).fetchone()
        if not row: raise ValueError("Baseline not found")
        d=dict(row); d["payload"]=json.loads(d["payload"]); return d
    @staticmethod
    def compare(before, after):
        b={p["name"]:p for p in before.get("pods",[])}; a={p["name"]:p for p in after.get("pods",[])}
        return {
            "before_summary": before.get("summary",{}), "after_summary": after.get("summary",{}),
            "new_pods": [a[n] for n in a.keys()-b.keys()], "removed_pods": [b[n] for n in b.keys()-a.keys()],
            "restart_deltas": [{"pod":n,"before":b[n].get("restart_count",0),"after":a[n].get("restart_count",0),"delta":a[n].get("restart_count",0)-b[n].get("restart_count",0)} for n in a.keys() & b.keys() if a[n].get("restart_count",0)!=b[n].get("restart_count",0)]
        }
