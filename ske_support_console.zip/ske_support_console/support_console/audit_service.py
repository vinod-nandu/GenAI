import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

class AuditService:
    def __init__(self, db_path: Path):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        with sqlite3.connect(self.db_path) as con:
            con.execute("""CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, windows_user TEXT, cluster TEXT, mode TEXT,
                namespace TEXT, resource TEXT, action TEXT NOT NULL, status TEXT NOT NULL, details TEXT
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS baselines (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, cluster TEXT, mode TEXT, namespace TEXT,
                workload TEXT, payload TEXT NOT NULL
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS health_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, cluster TEXT, namespace TEXT, pod TEXT,
                container TEXT, ready INTEGER, restart_count INTEGER, image TEXT, image_id TEXT, reason TEXT
            )""")

    def add(self, **row):
        import getpass
        vals = {
            "ts": datetime.now(timezone.utc).isoformat(), "windows_user": getpass.getuser(),
            "cluster": row.get("cluster"), "mode": row.get("mode"), "namespace": row.get("namespace"),
            "resource": row.get("resource"), "action": row.get("action","UNKNOWN"), "status": row.get("status","OK"),
            "details": json.dumps(row.get("details",{}), default=str)
        }
        with sqlite3.connect(self.db_path) as con:
            con.execute("INSERT INTO audit_log(ts,windows_user,cluster,mode,namespace,resource,action,status,details) VALUES(:ts,:windows_user,:cluster,:mode,:namespace,:resource,:action,:status,:details)", vals)

    def recent(self, limit=200):
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            rows=con.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(r) for r in rows]
