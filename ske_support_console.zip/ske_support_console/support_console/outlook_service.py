from pathlib import Path

class OutlookService:
    def create_draft(self, subject: str, html_body: str, to: list[str], cc: list[str], attachment: Path | None = None):
        try:
            import win32com.client  # type: ignore
        except Exception as exc:
            raise RuntimeError("Microsoft Outlook integration requires Windows, Outlook desktop, and pywin32") from exc
        outlook=win32com.client.Dispatch("Outlook.Application")
        mail=outlook.CreateItem(0)
        mail.Subject=subject
        mail.HTMLBody=html_body
        mail.To=';'.join(to or [])
        mail.CC=';'.join(cc or [])
        if attachment:
            mail.Attachments.Add(str(Path(attachment).resolve()))
        mail.Display(False)
        return "Outlook draft opened for review"
