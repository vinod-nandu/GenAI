from __future__ import annotations
import json
import sqlite3
from pathlib import Path

import yaml
from flask import Blueprint, current_app, jsonify, render_template, request, send_file

from .config import AppConfig
from .kubectl_service import KubectlService, KubectlError
from .health_service import summarize, apply_restart_history
from .backup_service import BackupService
from .baseline_service import BaselineService
from .bundle_service import BundleService
from .outlook_service import OutlookService
from .report_service import health_html
from .compare_service import yaml_diff, configured_images
from .safety import require_confirmation, validate_name, validate_resource_type

bp = Blueprint("main", __name__)


def env():
    data = request.get_json(silent=True) or request.args
    cluster = data.get("cluster")
    mode = data.get("mode", "read_only")
    if mode not in {"read_only", "read_write"}:
        raise ValueError("Invalid login mode")
    cfg = AppConfig(current_app.config["ROOT_DIR"])
    context = cfg.context_for(cluster, mode)
    return data, cfg, KubectlService(context), cluster, mode, context


def audit(cluster, mode, action, status="OK", namespace=None, resource=None, details=None):
    current_app.config["AUDIT"].add(
        cluster=cluster, mode=mode, action=action, status=status,
        namespace=namespace, resource=resource, details=details or {}
    )


def workload_pods(k: KubectlService, namespace: str, workload: dict):
    selector = workload.get("spec", {}).get("selector", {}).get("matchLabels", {})
    raw_pods = k.pods(namespace)
    if not selector:
        return raw_pods
    out = []
    for pod in raw_pods:
        labels = pod.get("metadata", {}).get("labels", {})
        if all(labels.get(a) == b for a, b in selector.items()):
            out.append(pod)
    return out


def runtime_image_metadata(pods: list[dict]):
    out = []
    for pod in pods:
        for cs in pod.get("status", {}).get("containerStatuses", []) or []:
            out.append({
                "pod": pod.get("metadata", {}).get("name"),
                "container": cs.get("name"),
                "image": cs.get("image"),
                "image_id": cs.get("imageID"),
                "restart_count": cs.get("restartCount", 0),
            })
    return out


@bp.errorhandler(Exception)
def error(exc):
    code = 502 if isinstance(exc, KubectlError) else 400
    return jsonify({"ok": False, "error": str(exc)}), code


@bp.get("/")
def index():
    cfg = AppConfig(current_app.config["ROOT_DIR"])
    return render_template("index.html", clusters=list(cfg.clusters.get("clusters", {}).keys()))


@bp.post("/api/connect")
def connect():
    data, cfg, k, cluster, mode, context = env()
    ns = data.get("namespace") or None
    caps = {
        "get_pods": k.auth_can_i("get", "pods", ns),
        "logs": k.auth_can_i("get", "pods/log", ns),
        "patch_deployments": k.auth_can_i("patch", "deployments", ns),
        "update_deployments": k.auth_can_i("update", "deployments", ns),
        "get_secrets": k.auth_can_i("get", "secrets", ns),
    }
    audit(cluster, mode, "CONNECT", namespace=ns, details={"context": context, "capabilities": caps})
    return jsonify({"ok": True, "context": context, "capabilities": caps})


@bp.get("/api/namespaces")
def namespaces():
    data, cfg, k, cluster, mode, context = env()
    return jsonify({"ok": True, "items": k.namespaces()})


@bp.get("/api/deployments")
def deployments():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    items = []
    for d in k.deployments(ns):
        st = d.get("status", {})
        spec = d.get("spec", {})
        items.append({
            "name": d["metadata"]["name"], "desired": spec.get("replicas", 0),
            "updated": st.get("updatedReplicas", 0), "ready": st.get("readyReplicas", 0),
            "available": st.get("availableReplicas", 0), "unavailable": st.get("unavailableReplicas", 0),
        })
    return jsonify({"ok": True, "items": items})


@bp.get("/api/resource/yaml")
def resource_yaml():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    rtype = validate_resource_type(data.get("resource_type"))
    name = validate_name(data.get("name"))
    return jsonify({"ok": True, "yaml": k.resource_yaml(rtype, name, ns)})


@bp.get("/api/health")
def health():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    result = summarize(k.pods(ns))
    db = current_app.config["AUDIT"]
    previous = {}
    with sqlite3.connect(db.db_path) as con:
        for p in result["pods"]:
            for c in p["containers"]:
                row = con.execute(
                    "SELECT restart_count FROM health_history WHERE cluster=? AND namespace=? AND pod=? AND container=? ORDER BY id DESC LIMIT 1",
                    (cluster, ns, p["name"], c["name"]),
                ).fetchone()
                if row:
                    previous[(p["name"], c["name"])] = int(row[0])
    result = apply_restart_history(result, previous)
    with sqlite3.connect(db.db_path) as con:
        ts = result["summary"]["timestamp"]
        for p in result["pods"]:
            for c in p["containers"]:
                con.execute(
                    "INSERT INTO health_history(ts,cluster,namespace,pod,container,ready,restart_count,image,image_id,reason) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (ts, cluster, ns, p["name"], c["name"], 1 if c["ready"] else 0,
                     c["restart_count"], c["image"], c["image_id"], c["reason"]),
                )
    audit(cluster, mode, "HEALTH_CHECK", namespace=ns, details=result["summary"])
    return jsonify({"ok": True, **result})


@bp.get("/api/pod/investigate")
def investigate():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    pod = validate_name(data.get("pod"), "pod")
    container = data.get("container") or None
    out = {"describe": k.describe_pod(pod, ns), "events": k.events(ns)}
    try:
        out["current_logs"] = k.logs(pod, ns, container=container, tail=int(data.get("tail", 500)), since=data.get("since") or None)
    except Exception as e:
        out["current_logs_error"] = str(e)
    try:
        out["previous_logs"] = k.logs(pod, ns, container=container, previous=True, tail=int(data.get("tail", 500)), since=data.get("since") or None)
    except Exception as e:
        out["previous_logs_error"] = str(e)
    audit(cluster, mode, "POD_INVESTIGATION", namespace=ns, resource=pod)
    return jsonify({"ok": True, **out})


@bp.get("/api/deployment/watch")
def deployment_watch():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    name = validate_name(data.get("deployment"), "deployment")
    dep = k.resource_json("deployment", name, ns)
    selected = summarize(workload_pods(k, ns, dep))["pods"]
    st, spec = dep.get("status", {}), dep.get("spec", {})
    return jsonify({
        "ok": True,
        "deployment": {
            "name": name, "desired": spec.get("replicas", 0), "updated": st.get("updatedReplicas", 0),
            "ready": st.get("readyReplicas", 0), "available": st.get("availableReplicas", 0),
            "unavailable": st.get("unavailableReplicas", 0), "images": configured_images(dep),
        },
        "pods": selected,
    })


@bp.post("/api/baseline/capture")
def baseline_capture():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    workload = validate_name(data.get("deployment"), "deployment")
    dep = k.resource_json("deployment", workload, ns)
    payload = summarize(workload_pods(k, ns, dep))
    payload["deployment"] = dep
    payload["runtime_images"] = runtime_image_metadata(workload_pods(k, ns, dep))
    bid = BaselineService(current_app.config["AUDIT"]).capture(cluster, mode, ns, workload, payload)
    audit(cluster, mode, "BASELINE_CAPTURE", namespace=ns, resource=workload, details={"baseline_id": bid})
    return jsonify({"ok": True, "baseline_id": bid})


@bp.get("/api/baseline/compare")
def baseline_compare():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    bid = int(data.get("baseline_id"))
    bs = BaselineService(current_app.config["AUDIT"])
    baseline = bs.get(bid)
    dep = k.resource_json("deployment", baseline["workload"], ns)
    after = summarize(workload_pods(k, ns, dep))
    after["deployment"] = dep
    after["runtime_images"] = runtime_image_metadata(workload_pods(k, ns, dep))
    comparison = bs.compare(baseline["payload"], after)
    comparison["configured_images_before"] = configured_images(baseline["payload"].get("deployment", {}))
    comparison["configured_images_after"] = configured_images(dep)
    comparison["runtime_images_before"] = baseline["payload"].get("runtime_images", [])
    comparison["runtime_images_after"] = after["runtime_images"]
    return jsonify({"ok": True, "comparison": comparison})


@bp.post("/api/backup")
def backup():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    rtype = validate_resource_type(data.get("resource_type"))
    name = validate_name(data.get("name"))
    y = k.resource_yaml(rtype, name, ns)
    obj = k.resource_json(rtype, name, ns)
    pods = workload_pods(k, ns, obj) if rtype in {"deployment", "deployments", "statefulset", "statefulsets", "daemonset", "daemonsets"} else []
    metadata = {
        "cluster": cluster, "namespace": ns, "resource": name, "resource_type": rtype, "mode": mode,
        "configured_images": configured_images(obj), "runtime_images": runtime_image_metadata(pods),
    }
    result = BackupService(current_app.config["ROOT_DIR"]).save(cluster, ns, rtype, name, y, metadata)
    audit(cluster, mode, "BACKUP_CREATED", namespace=ns, resource=name, details=result)
    return jsonify({"ok": True, **result})


@bp.get("/api/backup/list")
def backup_list():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    rtype = validate_resource_type(data.get("resource_type"))
    name = validate_name(data.get("name"))
    items = BackupService(current_app.config["ROOT_DIR"]).list(cluster, ns, rtype, name)
    return jsonify({"ok": True, "items": items})


@bp.get("/api/backup/compare")
def backup_compare():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    rtype = validate_resource_type(data.get("resource_type"))
    name = validate_name(data.get("name"))
    saved = BackupService(current_app.config["ROOT_DIR"]).read(data.get("backup_id"))
    current_yaml = k.resource_yaml(rtype, name, ns)
    current_obj = k.resource_json(rtype, name, ns)
    pods = workload_pods(k, ns, current_obj) if rtype in {"deployment", "deployments", "statefulset", "statefulsets", "daemonset", "daemonsets"} else []
    comp = yaml_diff(saved["yaml"], current_yaml)
    comp["backup_configured_images"] = saved["metadata"].get("configured_images", [])
    comp["current_configured_images"] = configured_images(current_obj)
    comp["backup_runtime_images"] = saved["metadata"].get("runtime_images", [])
    comp["current_runtime_images"] = runtime_image_metadata(pods)
    audit(cluster, mode, "BACKUP_COMPARE", namespace=ns, resource=name, details={"backup_id": data.get("backup_id"), "different": comp["different"]})
    return jsonify({"ok": True, "comparison": comp})


@bp.post("/api/config/dry-run")
def dry_run():
    data, cfg, k, cluster, mode, context = env()
    y = data.get("yaml", "")
    if mode != "read_write":
        raise PermissionError("Configuration changes require HP read/write mode")
    parsed = yaml.safe_load(y)
    ns = ((parsed or {}).get("metadata") or {}).get("namespace") or data.get("namespace")
    validate_name(ns, "namespace")
    return jsonify({"ok": True, "output": k.apply_yaml(y, True)})


@bp.post("/api/config/diff")
def config_diff():
    data, cfg, k, cluster, mode, context = env()
    y = data.get("yaml", "")
    parsed = yaml.safe_load(y) or {}
    meta = parsed.get("metadata") or {}
    kind = (parsed.get("kind") or "").lower()
    rtype = {"deployment":"deployment", "statefulset":"statefulset", "daemonset":"daemonset", "service":"service", "configmap":"configmap"}.get(kind)
    if not rtype:
        raise ValueError("Only approved resource kinds can be compared from the UI")
    name = validate_name(meta.get("name"))
    ns = validate_name(meta.get("namespace") or data.get("namespace"), "namespace")
    current_yaml = k.resource_yaml(rtype, name, ns)
    comp = yaml_diff(current_yaml, y)
    return jsonify({"ok": True, "comparison": comp})


@bp.post("/api/config/apply")
def apply_config():
    data, cfg, k, cluster, mode, context = env()
    y = data.get("yaml", "")
    if mode != "read_write":
        raise PermissionError("Configuration changes require HP read/write mode")
    require_confirmation(data, "APPLY")
    parsed = yaml.safe_load(y) or {}
    meta = parsed.get("metadata") or {}
    kind = (parsed.get("kind") or "").lower()
    name = validate_name(meta.get("name"))
    ns = validate_name(meta.get("namespace") or data.get("namespace"), "namespace")
    rtype = {"deployment":"deployment", "statefulset":"statefulset", "daemonset":"daemonset", "service":"service", "configmap":"configmap"}.get(kind)
    if not rtype:
        raise ValueError("Only approved resource kinds can be applied from the UI")
    old = k.resource_yaml(rtype, name, ns)
    old_obj = k.resource_json(rtype, name, ns)
    BackupService(current_app.config["ROOT_DIR"]).save(
        cluster, ns, rtype, name, old,
        {"cluster":cluster, "namespace":ns, "resource":name, "resource_type":rtype, "mode":mode,
         "configured_images":configured_images(old_obj)}
    )
    k.apply_yaml(y, True)
    out = k.apply_yaml(y, False)
    audit(cluster, mode, "CONFIG_APPLY", namespace=ns, resource=name)
    return jsonify({"ok": True, "output": out})


@bp.post("/api/restart")
def restart():
    data, cfg, k, cluster, mode, context = env()
    if mode != "read_write":
        raise PermissionError("Restart requires HP read/write mode")
    kind = data.get("kind")
    name = validate_name(data.get("name"))
    ns = validate_name(data.get("namespace"), "namespace")
    require_confirmation(data, "RESTART")
    old = k.resource_yaml(kind, name, ns)
    old_obj = k.resource_json(kind, name, ns)
    BackupService(current_app.config["ROOT_DIR"]).save(
        cluster, ns, kind, name, old,
        {"cluster":cluster, "namespace":ns, "resource":name, "resource_type":kind, "mode":mode,
         "configured_images":configured_images(old_obj)}
    )
    out = k.rollout_restart(kind, name, ns)
    audit(cluster, mode, "ROLLOUT_RESTART", namespace=ns, resource=name)
    return jsonify({"ok": True, "output": out})


@bp.get("/api/rollout/status")
def rollout_status():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    kind = data.get("kind", "deployment")
    name = validate_name(data.get("name"))
    out = k.rollout_status(kind, name, ns, timeout_seconds=int(data.get("timeout", 180)))
    audit(cluster, mode, "ROLLOUT_STATUS", namespace=ns, resource=name)
    return jsonify({"ok": True, "output": out})


@bp.post("/api/rollback")
def rollback():
    data, cfg, k, cluster, mode, context = env()
    if mode != "read_write":
        raise PermissionError("Rollback requires HP read/write mode")
    ns = validate_name(data.get("namespace"), "namespace")
    kind = data.get("kind", "deployment")
    name = validate_name(data.get("name"))
    require_confirmation(data, "ROLLBACK")
    current_yaml = k.resource_yaml(kind, name, ns)
    current_obj = k.resource_json(kind, name, ns)
    BackupService(current_app.config["ROOT_DIR"]).save(
        cluster, ns, kind, name, current_yaml,
        {"cluster":cluster, "namespace":ns, "resource":name, "resource_type":kind, "mode":mode,
         "configured_images":configured_images(current_obj), "reason":"pre-rollback"}
    )
    revision = data.get("revision")
    out = k.rollout_undo(kind, name, ns, int(revision) if str(revision or "").strip() else None)
    audit(cluster, mode, "ROLLBACK", namespace=ns, resource=name, details={"revision": revision})
    return jsonify({"ok": True, "output": out})


@bp.post("/api/bundle")
def bundle():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    pod = data.get("pod")
    container = data.get("container") or None
    selected = data.get("items") or []
    artifacts = {}
    if "health_summary" in selected:
        artifacts["health_summary"] = summarize(k.pods(ns))
    if pod:
        pod = validate_name(pod, "pod")
        if "pod_describe" in selected:
            artifacts["pod_describe"] = k.describe_pod(pod, ns)
        if "current_logs" in selected:
            try:
                artifacts["current_logs"] = k.logs(pod, ns, container=container, tail=int(data.get("tail", 500)), since=data.get("since") or None)
            except Exception as e:
                artifacts["current_logs"] = "ERROR: " + str(e)
        if "previous_logs" in selected:
            try:
                artifacts["previous_logs"] = k.logs(pod, ns, container=container, previous=True, tail=int(data.get("tail", 500)), since=data.get("since") or None)
            except Exception as e:
                artifacts["previous_logs"] = "ERROR: " + str(e)
    if "events" in selected:
        artifacts["events"] = k.events(ns)
    if "deployment_yaml" in selected and data.get("deployment"):
        artifacts["deployment_yaml"] = k.resource_yaml("deployment", validate_name(data.get("deployment")), ns)
    if "image_info" in selected and data.get("deployment"):
        dep = k.resource_json("deployment", validate_name(data.get("deployment")), ns)
        artifacts["image_info"] = {"configured": configured_images(dep), "runtime": runtime_image_metadata(workload_pods(k, ns, dep))}
    if "kubeconfig_redacted" in selected:
        artifacts["kubeconfig_redacted"] = k.redacted_kubeconfig()
    if "secret_metadata" in selected:
        secrets = k.json(["get", "secrets", "-n", ns]).get("items", [])
        artifacts["secret_metadata"] = [
            {"name":s.get("metadata",{}).get("name"), "type":s.get("type"), "keys":sorted((s.get("data") or {}).keys())}
            for s in secrets
        ]
    if "serviceaccount_metadata" in selected:
        sas = k.json(["get", "serviceaccounts", "-n", ns]).get("items", [])
        artifacts["serviceaccount_metadata"] = [
            {"name":s.get("metadata",{}).get("name"),
             "secrets":[x.get("name") for x in s.get("secrets",[])],
             "imagePullSecrets":[x.get("name") for x in s.get("imagePullSecrets",[])]}
            for s in sas
        ]
    if "audit_summary" in selected:
        artifacts["audit_summary"] = current_app.config["AUDIT"].recent(50)
    path = BundleService(current_app.config["ROOT_DIR"]).create(selected, artifacts, f"{cluster}_{ns}_{pod or 'namespace'}")
    audit(cluster, mode, "DIAGNOSTIC_BUNDLE", namespace=ns, resource=pod, details={"items": selected, "path": str(path)})
    return jsonify({"ok": True, "path": str(path), "filename": path.name})


@bp.get("/api/report/download")
def report_download():
    name = Path(request.args.get("name", "")).name
    path = current_app.config["ROOT_DIR"] / "reports" / name
    if not path.exists():
        raise ValueError("Report not found")
    return send_file(path, as_attachment=True)


@bp.post("/api/email/draft")
def email_draft():
    data, cfg, k, cluster, mode, context = env()
    ns = validate_name(data.get("namespace"), "namespace")
    result = summarize(k.pods(ns))
    mailcfg = cfg.mail.get("clusters", {}).get(cluster, {}) or {}
    attachment = None
    if data.get("bundle_filename"):
        p = current_app.config["ROOT_DIR"] / "reports" / Path(data["bundle_filename"]).name
        if p.exists():
            attachment = p
    subject = f"[Kubernetes Health Check] {cluster} | {ns} | {result['summary']['overall']}"
    msg = OutlookService().create_draft(
        subject, health_html(cluster, ns, result),
        data.get("to") or mailcfg.get("to", []), data.get("cc") or mailcfg.get("cc", []), attachment
    )
    audit(cluster, mode, "EMAIL_DRAFT_CREATED", namespace=ns, details={"subject":subject, "attachment":attachment.name if attachment else None})
    return jsonify({"ok": True, "message": msg})


@bp.get("/api/audit")
def audits():
    return jsonify({"ok": True, "items": current_app.config["AUDIT"].recent()})
