from pathlib import Path
import yaml

class AppConfig:
    def __init__(self, root: Path):
        self.root = root
        self.clusters = self._load(root / "config" / "clusters.yaml")
        self.mail = self._load(root / "config" / "mail.yaml")
        self.app = self._load(root / "config" / "app.yaml")
        self.health_rules = self._load(root / "config" / "health_rules.yaml")

    @staticmethod
    def _load(path: Path):
        with path.open("r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}

    def context_for(self, cluster: str, mode: str) -> str:
        c = self.clusters["clusters"].get(cluster)
        if not c:
            raise ValueError("Unknown cluster")
        key = "read_only_context" if mode == "read_only" else "read_write_context"
        value = c.get(key)
        if not value:
            raise ValueError(f"No context configured for {cluster}/{mode}")
        return value
