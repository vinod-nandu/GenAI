from __future__ import annotations
import difflib
import yaml

GENERATED_METADATA = {"resourceVersion", "uid", "managedFields", "creationTimestamp", "generation", "selfLink"}

def normalize_object(obj):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k == "status":
                continue
            if k in GENERATED_METADATA:
                continue
            out[k] = normalize_object(v)
        return out
    if isinstance(obj, list):
        return [normalize_object(x) for x in obj]
    return obj

def yaml_diff(before_yaml: str, after_yaml: str):
    before = normalize_object(yaml.safe_load(before_yaml) or {})
    after = normalize_object(yaml.safe_load(after_yaml) or {})
    btxt = yaml.safe_dump(before, sort_keys=True).splitlines()
    atxt = yaml.safe_dump(after, sort_keys=True).splitlines()
    diff = "\n".join(difflib.unified_diff(btxt, atxt, fromfile="backup", tofile="current", lineterm=""))
    return {"different": before != after, "diff": diff, "backup_normalized": before, "current_normalized": after}

def configured_images(obj: dict):
    spec = obj.get("spec", {})
    pod_spec = spec.get("template", {}).get("spec", {}) if "template" in spec else spec
    return [{"name": c.get("name"), "image": c.get("image")} for c in pod_spec.get("containers", [])]
