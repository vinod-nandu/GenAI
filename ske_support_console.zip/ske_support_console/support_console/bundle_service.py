from __future__ import annotations
import json
import zipfile
from datetime import datetime
from pathlib import Path
from .safety import SAFE_BUNDLE_ITEMS

class BundleService:
    def __init__(self, root: Path):
        self.root=root
        (root/"reports").mkdir(exist_ok=True)

    def create(self, selected: list[str], artifacts: dict, label: str):
        unknown=set(selected)-SAFE_BUNDLE_ITEMS
        if unknown: raise ValueError(f"Unsupported bundle items: {sorted(unknown)}")
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
        safe=''.join(ch if ch.isalnum() or ch in '-_' else '_' for ch in label)[:80]
        path=self.root/"reports"/f"diagnostic_{safe}_{stamp}.zip"
        manifest={"created":stamp,"selected":selected,"security_note":"Credential material and Secret values are intentionally excluded/redacted."}
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json",json.dumps(manifest,indent=2))
            for item in selected:
                value=artifacts.get(item)
                if value is None: continue
                if not isinstance(value,str): value=json.dumps(value,indent=2,default=str)
                ext='json' if value.lstrip().startswith(('{','[')) else 'txt'
                z.writestr(f"{item}.{ext}",value)
        return path
