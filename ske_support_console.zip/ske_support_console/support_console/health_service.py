from __future__ import annotations
from datetime import datetime, timezone

def _owner(pod: dict):
    refs = pod.get("metadata", {}).get("ownerReferences", [])
    return refs[0].get("kind"), refs[0].get("name") if refs else (None, None)

def pod_health(pod: dict) -> dict:
    meta = pod.get("metadata", {})
    status = pod.get("status", {})
    spec = pod.get("spec", {})
    conditions = {c.get("type"): c.get("status") for c in status.get("conditions", [])}
    statuses = status.get("containerStatuses", []) or []
    containers = []
    highest = "HEALTHY"
    rank = {"HEALTHY":0,"INFO":1,"WARNING":2,"CRITICAL":3}
    for cs in statuses:
        state = cs.get("state", {})
        waiting = state.get("waiting", {}) or {}
        terminated = state.get("terminated", {}) or {}
        last_term = (cs.get("lastState", {}) or {}).get("terminated", {}) or {}
        reason = waiting.get("reason") or terminated.get("reason") or last_term.get("reason") or ""
        restarts = int(cs.get("restartCount", 0))
        cls = "HEALTHY"
        if reason in {"CrashLoopBackOff","ImagePullBackOff","ErrImagePull","OOMKilled","CreateContainerConfigError"}: cls = "CRITICAL"
        elif restarts > 0 or cs.get("ready") is False: cls = "WARNING"
        if rank[cls] > rank[highest]: highest = cls
        containers.append({
            "name": cs.get("name"), "ready": cs.get("ready", False), "restart_count": restarts,
            "image": cs.get("image"), "image_id": cs.get("imageID"), "reason": reason,
            "exit_code": terminated.get("exitCode", last_term.get("exitCode")),
            "finished_at": terminated.get("finishedAt", last_term.get("finishedAt")), "classification": cls
        })
    phase = status.get("phase", "Unknown")
    if phase in {"Failed", "Unknown"}: highest = "CRITICAL"
    elif conditions.get("Ready") != "True" and highest != "CRITICAL": highest = "WARNING"
    return {
        "name": meta.get("name"), "namespace": meta.get("namespace"), "phase": phase,
        "ready": conditions.get("Ready") == "True", "node": spec.get("nodeName"), "pod_ip": status.get("podIP"),
        "created": meta.get("creationTimestamp"), "containers": containers,
        "restart_count": sum(c["restart_count"] for c in containers), "health": highest
    }

def summarize(pods: list[dict]) -> dict:
    items = [pod_health(p) for p in pods]
    summary = {"total": len(items), "healthy":0, "warning":0, "critical":0, "running":0, "pending":0, "failed":0, "restarted":0}
    for p in items:
        summary[p["health"].lower()] = summary.get(p["health"].lower(),0)+1
        phase = p["phase"].lower()
        if phase in summary: summary[phase]+=1
        if p["restart_count"]>0: summary["restarted"] += 1
    summary["overall"] = "CRITICAL" if summary["critical"] else ("WARNING" if summary["warning"] else "HEALTHY")
    summary["timestamp"] = datetime.now(timezone.utc).isoformat()
    return {"summary": summary, "pods": items}


def apply_restart_history(result: dict, previous: dict[tuple[str,str], int]):
    for pod in result.get("pods", []):
        pod_health_state = pod.get("health", "HEALTHY")
        for c in pod.get("containers", []):
            key=(pod.get("name"), c.get("name"))
            prev=previous.get(key)
            c["previous_restart_count"] = prev
            c["restart_delta"] = None if prev is None else c.get("restart_count",0)-prev
            if c["restart_delta"] is not None and c["restart_delta"] > 0 and c.get("classification") != "CRITICAL":
                c["classification"]="WARNING"
                if pod_health_state == "HEALTHY": pod_health_state="WARNING"
        pod["health"] = pod_health_state
    # Recount after restart-delta enrichment.
    s={"total":len(result.get("pods",[])),"healthy":0,"warning":0,"critical":0,"running":0,"pending":0,"failed":0,"restarted":0}
    for pod in result.get("pods",[]):
        s[pod.get("health","HEALTHY").lower()] += 1
        ph=pod.get("phase","").lower()
        if ph in s: s[ph]+=1
        if pod.get("restart_count",0)>0: s["restarted"]+=1
    s["overall"]="CRITICAL" if s["critical"] else ("WARNING" if s["warning"] else "HEALTHY")
    s["timestamp"]=result.get("summary",{}).get("timestamp")
    result["summary"]=s
    return result
