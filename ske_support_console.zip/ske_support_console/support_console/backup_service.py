from __future__ import annotations
from datetime import datetime
from pathlib import Path
import json

class BackupService:
    def __init__(self, root: Path):
        self.root = root / "backups"
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, cluster: str, namespace: str, rtype: str, name: str, yaml_text: str, metadata: dict):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        d = self.root / cluster / namespace / f"{rtype}_{name}"
        d.mkdir(parents=True, exist_ok=True)
        y = d / f"{stamp}.yaml"; j = d / f"{stamp}.json"
        y.write_text(yaml_text, encoding="utf-8")
        j.write_text(json.dumps(metadata, indent=2, default=str), encoding="utf-8")
        return {"yaml": str(y), "metadata": str(j), "backup_id": str(y.relative_to(self.root)).replace("\\", "/")}

    def _resolve(self, backup_id: str) -> Path:
        p = (self.root / backup_id).resolve()
        root = self.root.resolve()
        if root not in p.parents or p.suffix.lower() != ".yaml":
            raise ValueError("Invalid backup id")
        return p

    def read(self, backup_id: str):
        p = self._resolve(backup_id)
        if not p.exists(): raise ValueError("Backup not found")
        meta = p.with_suffix(".json")
        return {"yaml": p.read_text(encoding="utf-8"), "metadata": json.loads(meta.read_text(encoding="utf-8")) if meta.exists() else {}, "backup_id": backup_id}

    def list(self, cluster: str, namespace: str, rtype: str, name: str):
        d = self.root / cluster / namespace / f"{rtype}_{name}"
        if not d.exists(): return []
        out=[]
        for p in sorted(d.glob("*.yaml"), reverse=True):
            meta=p.with_suffix(".json")
            out.append({"backup_id":str(p.relative_to(self.root)).replace("\\","/"),"filename":p.name,"metadata":json.loads(meta.read_text(encoding="utf-8")) if meta.exists() else {}})
        return out
