from pathlib import Path

def create_app():
    from flask import Flask
    from .routes import bp
    from .audit_service import AuditService

    root = Path(__file__).resolve().parent.parent
    app = Flask(__name__, template_folder=str(root / "templates"), static_folder=str(root / "static"))
    app.config["ROOT_DIR"] = root
    app.config["AUDIT"] = AuditService(root / "database" / "support.db")
    app.register_blueprint(bp)
    return app
