import re

DNS_RE = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$")
ALLOWED_RESOURCE_TYPES = {
    "deployment", "deployments", "statefulset", "statefulsets", "daemonset", "daemonsets",
    "pod", "pods", "service", "services", "configmap", "configmaps", "job", "jobs",
    "cronjob", "cronjobs", "replicaset", "replicasets", "horizontalpodautoscaler", "hpa",
    "poddisruptionbudget", "pdb", "ingress", "ingresses"
}

def validate_name(value: str, label: str = "name") -> str:
    if not value or len(value) > 253 or not DNS_RE.match(value):
        raise ValueError(f"Invalid Kubernetes {label}: {value!r}")
    return value

def validate_resource_type(value: str) -> str:
    if value not in ALLOWED_RESOURCE_TYPES:
        raise ValueError(f"Unsupported resource type: {value}")
    return value

def require_confirmation(data: dict, expected: str):
    if data.get("confirmation") != expected:
        raise PermissionError(f"Confirmation must exactly match: {expected}")

SAFE_BUNDLE_ITEMS = {
    "health_summary", "pod_describe", "current_logs", "previous_logs", "events",
    "deployment_yaml", "image_info", "audit_summary", "baseline_compare",
    "kubeconfig_redacted", "secret_metadata", "serviceaccount_metadata"
}
