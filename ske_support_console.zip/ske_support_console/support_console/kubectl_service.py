from __future__ import annotations
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from .safety import validate_name, validate_resource_type

class KubectlError(RuntimeError):
    def __init__(self, message: str, stderr: str = "", returncode: int | None = None):
        super().__init__(message)
        self.stderr = stderr
        self.returncode = returncode

class KubectlService:
    def __init__(self, context: str, timeout: int = 30):
        self.context = context
        self.timeout = timeout
        if shutil.which("kubectl") is None:
            raise KubectlError("kubectl is not installed or not available on PATH")

    def _run(self, args: list[str], timeout: int | None = None) -> subprocess.CompletedProcess:
        cmd = ["kubectl", "--context", self.context, *args]
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout or self.timeout, check=False)
        except subprocess.TimeoutExpired as exc:
            raise KubectlError(f"kubectl command timed out after {timeout or self.timeout}s") from exc
        if cp.returncode != 0:
            msg = cp.stderr.strip() or cp.stdout.strip() or "kubectl command failed"
            raise KubectlError(msg, cp.stderr, cp.returncode)
        return cp

    def json(self, args: list[str], timeout: int | None = None) -> dict[str, Any]:
        cp = self._run([*args, "-o", "json"], timeout)
        try:
            return json.loads(cp.stdout)
        except json.JSONDecodeError as exc:
            raise KubectlError("kubectl returned invalid JSON") from exc

    def text(self, args: list[str], timeout: int | None = None) -> str:
        return self._run(args, timeout).stdout

    def namespaces(self):
        return [i["metadata"]["name"] for i in self.json(["get", "namespaces"]).get("items", [])]

    def pods(self, namespace: str):
        validate_name(namespace, "namespace")
        return self.json(["get", "pods", "-n", namespace]).get("items", [])

    def deployments(self, namespace: str):
        validate_name(namespace, "namespace")
        return self.json(["get", "deployments", "-n", namespace]).get("items", [])

    def resource_json(self, rtype: str, name: str, namespace: str):
        validate_resource_type(rtype); validate_name(name); validate_name(namespace, "namespace")
        return self.json(["get", rtype, name, "-n", namespace])

    def resource_yaml(self, rtype: str, name: str, namespace: str):
        validate_resource_type(rtype); validate_name(name); validate_name(namespace, "namespace")
        return self.text(["get", rtype, name, "-n", namespace, "-o", "yaml"] )

    def describe_pod(self, pod: str, namespace: str):
        validate_name(pod, "pod"); validate_name(namespace, "namespace")
        return self.text(["describe", "pod", pod, "-n", namespace])

    def logs(self, pod: str, namespace: str, container: str | None = None, previous: bool = False, tail: int = 500, since: str | None = None):
        validate_name(pod, "pod"); validate_name(namespace, "namespace")
        if container: validate_name(container, "container")
        tail = max(1, min(int(tail), 10000))
        args = ["logs", pod, "-n", namespace, "--timestamps=true", f"--tail={tail}"]
        if container: args += ["-c", container]
        if previous: args.append("--previous")
        if since:
            if since not in {"5m", "15m", "1h", "6h", "24h"}:
                raise ValueError("Unsupported since value")
            args += ["--since", since]
        return self.text(args, timeout=60)

    def events(self, namespace: str):
        validate_name(namespace, "namespace")
        return self.json(["get", "events", "-n", namespace, "--sort-by=.lastTimestamp"]).get("items", [])

    def auth_can_i(self, verb: str, resource: str, namespace: str | None = None):
        allowed_verbs = {"get", "list", "watch", "patch", "update", "delete", "create"}
        if verb not in allowed_verbs: raise ValueError("Unsupported auth verb")
        args = ["auth", "can-i", verb, resource]
        if namespace:
            validate_name(namespace, "namespace"); args += ["-n", namespace]
        return self.text(args).strip().lower() == "yes"

    def rollout_status(self, kind: str, name: str, namespace: str, timeout_seconds: int = 180):
        if kind not in {"deployment", "statefulset", "daemonset"}: raise ValueError("Unsupported rollout kind")
        validate_name(name); validate_name(namespace, "namespace")
        return self.text(["rollout", "status", f"{kind}/{name}", "-n", namespace, f"--timeout={timeout_seconds}s"], timeout=timeout_seconds+15)

    def rollout_restart(self, kind: str, name: str, namespace: str):
        if kind not in {"deployment", "statefulset", "daemonset"}: raise ValueError("Unsupported restart kind")
        validate_name(name); validate_name(namespace, "namespace")
        return self.text(["rollout", "restart", f"{kind}/{name}", "-n", namespace])

    def rollout_undo(self, kind: str, name: str, namespace: str, revision: int | None = None):
        if kind not in {"deployment", "statefulset", "daemonset"}: raise ValueError("Unsupported rollback kind")
        validate_name(name); validate_name(namespace, "namespace")
        args = ["rollout", "undo", f"{kind}/{name}", "-n", namespace]
        if revision is not None: args += [f"--to-revision={int(revision)}"]
        return self.text(args)

    def apply_yaml(self, yaml_text: str, dry_run: bool):
        if len(yaml_text) > 2_000_000: raise ValueError("YAML payload too large")
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False, encoding="utf-8") as fh:
            fh.write(yaml_text); p = Path(fh.name)
        try:
            args = ["apply"]
            if dry_run: args += ["--dry-run=server"]
            args += ["-f", str(p)]
            return self.text(args, timeout=90)
        finally:
            p.unlink(missing_ok=True)

    def redacted_kubeconfig(self) -> str:
        # Flattened configuration is useful for context diagnostics, but all credentials are redacted.
        obj = self.json(["config", "view", "--raw=false", "--minify=false"])
        for u in obj.get("users", []):
            user = u.get("user", {})
            for k in list(user):
                lk = k.lower()
                if any(x in lk for x in ("token", "password", "client-key", "client-certificate-data", "auth-provider", "exec")):
                    user[k] = "<REDACTED>"
        return json.dumps(obj, indent=2)
