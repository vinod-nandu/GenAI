# Security Notes

This console is designed to reduce accidental production changes, but it is not a replacement for Kubernetes RBAC, enterprise authentication, change management, or endpoint security.

## Credential and Secret handling

The application does not export plaintext:

- kubeconfig bearer tokens
- passwords
- client private keys
- client certificate data
- exec-plugin authentication output
- Kubernetes Secret data values

The diagnostic ZIP instead supports:

- redacted kubeconfig/context metadata
- Secret names, Secret types, and key names
- ServiceAccount and imagePullSecret references

This is intentional. A ZIP intended for email is not an appropriate transport for reusable authentication material or application Secret values.

## Kubernetes execution safety

- `shell=True` is not used.
- `os.system` is not used.
- Every command receives an explicit kubeconfig context.
- Kubernetes names are validated.
- Write operations require `read_write` application mode and Kubernetes RBAC still applies.
- Apply uses a server-side dry run before actual apply.
- Supported changes create a backup first.

## Recommended organizational controls

- Use dedicated read-only and read/write kubeconfig contexts.
- Use least-privilege Kubernetes RBAC.
- Enforce MFA/enterprise authentication outside this application.
- Restrict filesystem permissions on `backups`, `reports`, and `database`.
- Set report/log retention limits.
- Do not place this application on a shared multi-user web server without a separate authentication and authorization design.
- Review Deployment/ConfigMap YAML for organization-specific sensitive fields before enabling broad report sharing.
