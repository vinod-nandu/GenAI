# Architecture and Operational Flow

## Architecture diagram

- `diagrams/architecture.png`
- `diagrams/architecture.svg`
- `diagrams/architecture.dot`

The local browser UI talks to a Flask service bound to `127.0.0.1`. The backend routes all Kubernetes access through one `KubectlService`, which invokes `kubectl` with an explicit selected context and safe argument arrays. Health, backup, baseline, bundle, Outlook, and audit services sit behind the Flask layer.

The HK/SG and Support/HP mappings are configuration-driven and live in `config/clusters.yaml`.

## Operational flow diagram

- `diagrams/flow.png`
- `diagrams/flow.svg`
- `diagrams/flow.dot`

The flow emphasizes:

1. Select cluster and identity.
2. Verify RBAC.
3. Run read-only health checks.
4. Investigate crash/restart conditions with current and previous logs.
5. Capture deployment baseline and monitor rollout.
6. For approved changes, back up, diff, dry-run, and confirm.
7. Verify post-deployment health and image/image-ID changes.
8. Create a selectable diagnostic ZIP.
9. Open a reviewable Outlook draft.
10. Record operational audit history.
